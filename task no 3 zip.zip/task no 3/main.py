
class TemperatureAgent:
    def __init__(self):
        self.heater_status = "OFF"
        self.threshold = 22
    
    def decide_action(self, temp):
        if temp < self.threshold and self.heater_status == "OFF":
            self.heater_status = "ON"
            return "Heater ON"
        elif temp >= self.threshold and self.heater_status == "ON":
            self.heater_status = "OFF"
            return "Heater OFF"
        elif self.heater_status == "ON":
            return "Already ON"
        else:
            return "Already OFF"


def main():
    agent = TemperatureAgent()
    test_temps = [18, 15, 25, 24, 19, 20, 26, 17]
    
    print("Temperature Controller")
    print("-" * 30)
    print("Threshold:", agent.threshold, "C")
    print()
    
    for temp in test_temps:
        print("Temp:", temp, "C")
        print("Action:", agent.decide_action(temp))
        print("Status:", agent.heater_status)
        print()
    
    print("Done")


if __name__ == "__main__":
    main()
